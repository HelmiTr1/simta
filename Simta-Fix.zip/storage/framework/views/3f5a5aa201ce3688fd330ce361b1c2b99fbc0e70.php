

<?php $__env->startSection('title'); ?>
    Berkas Revisi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bread'); ?>
<?php echo e(Breadcrumbs::render('revisi')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
  
  <?php if($params =='terima'): ?>
    <div class="col-xl-12">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0 text-success text-uppercase">Data revisi diterima</h3>
            </div>
          </div>
        </div>

        <?php echo e(session()->get('revisiname')); ?>

        <?php if(session('status')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="revisi1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Action</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Filename</th>
                <th scope="col">Tanggal Upload</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $revisi1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <form action="<?php echo e(url('berkas/revisi').'/'.$r1->id); ?>" method="post" class="d-inline">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Tolak"><i class="fas fa-fw fa-ban"></i></button>
                      </form>
                </td>
                <td>
                  <?php echo e($r1->nim); ?>

                      </td>
                      <td>
                          <?php echo e($r1->mahasiswa->nama); ?>

                      </td>
                      <?php
                      Date::setLocale('id');
                      $date = new Date($r->input_at);
                      ?>
                  <td><?php echo e($date->format('j F Y')); ?></td>
                      <td>
                      <a href="<?php echo e(url('berkas/revisi').'/'.$r1->id); ?>" target="_blank"><i class="ni ni-single-copy-04 text-xl"></i> <?php echo e($r1->filename); ?></a>
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php endif; ?>
    
    <?php if($params =='tolak'): ?>
    <div class="col-xl-12">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0 text-danger text-uppercase">Data revisi ditolak</h3>
            </div>
          </div>
        </div>
        <?php if(session('status1')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status1')); ?>

    </div>
<?php endif; ?>
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="revisi2" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Action</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Filename</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $revisi2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>
                  <form action="<?php echo e(url('berkas/revisi').'/'.$r2->id); ?>" method="post" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fas fa-fw fa-trash"></i></button>
                      </form>
                </td>
                    <td>
                        <?php echo e($r2->nim); ?>

                    </td>
                    <td>
                        <?php echo e($r2->mahasiswa->nama); ?>

                    </td>
                    <td>
                      <a href="<?php echo e(url('berkas/revisi').'/'.$r2->id); ?>" target="_blank" data-toggle="tooltip" data-placement="top" data-title="Preview"><i class="ni ni-single-copy-04 text-xl"></i> <?php echo e($r2->filename); ?></a>
                      </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#revisi1').DataTable()
            $('#revisi2').DataTable()
        });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Simta-Fix\resources\views/revisi/index.blade.php ENDPATH**/ ?>