
<?php $__env->startSection('title'); ?>
    Sidang
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
<?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-xl-4 col-md-6">
    <a href="<?php echo e(url('/').'/'.$c->url); ?>" class="d-0">
      <div class="card card-stats">
        <!-- Card body -->
        <div class="card-body">
          <div class="row">
            <div class="col">
            <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e($c->level->level); ?></h5>
            <span class="h2 font-weight-bold mb-0"><?php echo e($c->judul); ?></span>
            </div>
            <div class="col-auto">
              <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
              <i class="<?php echo e($c->icon); ?>"></i>
              </div>
            </div>
          </div>
          <p class="mt-3 mb-0 text-sm">
          <span class="text-wrap"><?php echo e($c->isi); ?></span>
          </p>
        </div>
      </div>
    </a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bread'); ?>
<?php echo e(Breadcrumbs::render('sidang')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Simta-Fix\resources\views/sidang/index.blade.php ENDPATH**/ ?>