
<?php $__env->startSection('title'); ?>
    Data Ruangan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bread'); ?>
<?php echo e(Breadcrumbs::render('ruangan')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-8">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Data Ruangan</h3>
            </div>
            <div class="col text-right">
              <a href="<?php echo e(url('sidang/ruangan/create')); ?>" class="btn btn-sm btn-primary">Tambah Ruangan</a>
              </div>
          </div>
        </div>

        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="ruangan1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Action</th>
                <th scope="col">Kode Ruangan</th>
                <th scope="col">Ruangan</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <a href="<?php echo e(url('sidang/ruangan').'/'.$r->id.'/edit'); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fas fa-fw fa-edit"></i></a>
                        <form action="<?php echo e(url('sidang/ruangan').'/'.$r->id); ?>" method="post" class="d-inline">
                          <?php echo method_field('delete'); ?>
                          <?php echo csrf_field(); ?>
                          <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fas fa-fw fa-trash"></i></button>
                            </form>
                      </td>
                      <td>
                        <?php echo e($r->kode_ruangan); ?>

                      </td>
                      <td>
                        <?php echo e($r->nama_ruangan); ?>

                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
    $(document).ready(function(){
        $('#ruangan1').DataTable();
        
    })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Simta-Fix\resources\views/ruangan/index.blade.php ENDPATH**/ ?>