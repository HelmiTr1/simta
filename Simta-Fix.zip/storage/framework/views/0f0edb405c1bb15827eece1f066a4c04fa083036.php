<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-8">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Tambah User</h3>
            </div>
          </div>
          <hr class="mb-0">
        </div>
<div class="card-body">
    <form>
        <div class="form-group row">
          <label for="inputUsername3" class="col-sm-2 col-form-label">Username</label>
          <div class="col-sm-10">
            <input type="Text" class="form-control" id="inputUsername3" placeholder="Username">
          </div>
        </div>
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
          </div>
        </div>
        <div class="form-group row">
          <label for="inputPassword4" class="col-sm-2 col-form-label">Confirm Password</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" id="inputPassword4" placeholder="Confirm Password">
          </div>
        </div>
        <div class="form-group row">
          <label for="inputLevel4" class="col-sm-2 col-form-label">Level</label>
          <div class="col-sm-10">
              <select name="level" id="level" class="form-control">
                  <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($l->id); ?>"><?php echo e($l->level); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
        </div>
        <div class="form-group row text-right">
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Sign in</button>
          </div>
        </div>
      </form>
</div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Simta-Fix\resources\views/welcome.blade.php ENDPATH**/ ?>