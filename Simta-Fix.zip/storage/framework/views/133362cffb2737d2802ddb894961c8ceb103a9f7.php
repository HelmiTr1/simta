

<?php $__env->startSection('bread'); ?>
<?php echo e(Breadcrumbs::render('nilai')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Nilai Sidang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="col-xl-12">
        <div class="card">
        <div class="card-header border-0">
            
        </div>
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
        <?php if(session('edit')): ?>
        <div class="alert alert-warning">
            <?php echo e(session('edit')); ?>

        </div>
    <?php endif; ?>
        <div class="table-responsive">
            
            <!-- Projects table -->
            <table id="nilai1" class="table align-items-center table-flush">
              <thead class="thead-light">
                <tr>
                  <th scope="col">NIM</th>
                  <th scope="col">Mahasiswa</th>
                  <th scope="col">Nilai Sidang TA</th>
                  <th scope="col">Nilai Proses Pengerjaan TA</th>
                </tr>
              </thead>
              <tbody>
                <?php
                      $i=0;
                ?>
                <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($data->nim); ?></td>
                    <td><?php echo e($data->mhs); ?></td>
                    <td>
                      <?php
                    if (count($nilais[$i]) == 0) {
                      ?>
                      <a href="<?php echo e(url('sidang/nilai/create').'?id='.$data->nim.'&&p=s'); ?>" class="btn btn-danger btn-sm">Nilai</a>
                    <?php
                    }else{?>
                    <a href="<?php echo e(url('sidang/nilai').'/'.$data->nim.'/edit?p=s'); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="<?php echo e(url('sidang/nilai').'/'.$data->nim.'/edit?p=s&&d=detail'); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fas fa-fw fa-eye"></i></a>
                    <?php
                    }?>
                    </td>
                    <td>
                    <?php if($data->dosenp1 == Auth::user()->username || $data->dosenp2 == Auth::user()->username): ?>
                    <?php
                    if (count($nilaip[$i]) == 0) {
                      ?>
                      <a href="<?php echo e(url('sidang/nilai/create').'?id='.$data->nim.'&&p=p'); ?>" class="btn btn-danger btn-sm">Nilai</a>
                    <?php
                    }else{?>
                    <a href="<?php echo e(url('sidang/nilai').'/'.$data->nim.'/edit?p=p'); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="<?php echo e(url('sidang/nilai').'/'.$data->nim.'/edit?p=p&&d=detail'); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fas fa-fw fa-eye"></i></a>
                    <?php
                    }?>
                    <?php endif; ?>
                    </td>
                    </tr>
                    <?php
                        $i++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>

    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nilai1').DataTable()
        });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Simta-Fix\resources\views/nilai/index.blade.php ENDPATH**/ ?>