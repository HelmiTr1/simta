@extends('layouts.app')

@section('title')
    Berkas Revisi
@endsection
@section('bread')
{{ Breadcrumbs::render('revisi') }}
@endsection
@section('content')

<div class="row">
  {{-- start region --}}
  @if($params =='terima')
    <div class="col-xl-12">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0 text-success text-uppercase">Data revisi diterima</h3>
            </div>
          </div>
        </div>

        {{session()->get('revisiname')}}
        @if (session('status'))
    <div class="alert alert-danger">
        {{ session('status') }}
    </div>
@endif
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="revisi1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Action</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Filename</th>
                <th scope="col">Tanggal Upload</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($revisi1 as $r1)
              <tr>
                <td>
                  <form action="{{url('berkas/revisi').'/'.$r1->id}}" method="post" class="d-inline">
                    @method('patch')
                    @csrf
                    <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Tolak"><i class="fas fa-fw fa-ban"></i></button>
                      </form>
                </td>
                <td>
                  {{$r1->nim}}
                      </td>
                      <td>
                          {{$r1->mahasiswa->nama}}
                      </td>
                      <?php
                      Date::setLocale('id');
                      $date = new Date($r->input_at);
                      ?>
                  <td>{{$date->format('j F Y')}}</td>
                      <td>
                      <a href="{{url('berkas/revisi').'/'.$r1->id}}" target="_blank"><i class="ni ni-single-copy-04 text-xl"></i> {{$r1->filename}}</a>
                      </td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
    @endif
    {{-- endregion --}}
    @if($params =='tolak')
    <div class="col-xl-12">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0 text-danger text-uppercase">Data revisi ditolak</h3>
            </div>
          </div>
        </div>
        @if (session('status1'))
    <div class="alert alert-success">
        {{ session('status1') }}
    </div>
@endif
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="revisi2" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Action</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Filename</th>
              </tr>
            </thead>
            <tbody>
                @foreach ($revisi2 as $r2)
                <tr>
                <td>
                  <form action="{{url('berkas/revisi').'/'.$r2->id}}" method="post" class="d-inline">
                    @method('delete')
                    @csrf
                    <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fas fa-fw fa-trash"></i></button>
                      </form>
                </td>
                    <td>
                        {{$r2->nim}}
                    </td>
                    <td>
                        {{$r2->mahasiswa->nama}}
                    </td>
                    <td>
                      <a href="{{url('berkas/revisi').'/'.$r2->id}}" target="_blank" data-toggle="tooltip" data-placement="top" data-title="Preview"><i class="ni ni-single-copy-04 text-xl"></i> {{$r2->filename}}</a>
                      </td>
                </tr>
            @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
    @endif
</div>
@endsection

@section('footer')

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#revisi1').DataTable()
            $('#revisi2').DataTable()
        });
        </script>
@endsection