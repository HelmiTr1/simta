@extends('layouts.app')
@section('title')
    Data Ruangan
@endsection
@section('bread')
{{ Breadcrumbs::render('ruangan') }}
@endsection
@section('content')
<div class="row">
    <div class="col-xl-8">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Data Ruangan</h3>
            </div>
            <div class="col text-right">
              <a href="{{url('sidang/ruangan/create')}}" class="btn btn-sm btn-primary">Tambah Ruangan</a>
              </div>
          </div>
        </div>

        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="ruangan1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Action</th>
                <th scope="col">Kode Ruangan</th>
                <th scope="col">Ruangan</th>
              </tr>
            </thead>
            <tbody>
                @foreach ($ruangan as $r)
                    <tr>
                      <td>
                        <a href="{{url('sidang/ruangan').'/'.$r->id.'/edit'}}" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fas fa-fw fa-edit"></i></a>
                        <form action="{{url('sidang/ruangan').'/'.$r->id}}" method="post" class="d-inline">
                          @method('delete')
                          @csrf
                          <button type="submit" class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fas fa-fw fa-trash"></i></button>
                            </form>
                      </td>
                      <td>
                        {{$r->kode_ruangan}}
                      </td>
                      <td>
                        {{$r->nama_ruangan}}
                      </td>
                    </tr>
                @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
@endsection
@section('footer')
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
    $(document).ready(function(){
        $('#ruangan1').DataTable();
        
    })
    </script>
@endsection

