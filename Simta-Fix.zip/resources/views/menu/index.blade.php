@extends('layouts.app')

@section('title')
    Data Menu
@endsection
@section('content')
<div class="row">
    <div class="col-xl-8">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Data Menu</h3>
            </div>
            <div class="col text-right">
            <a href="{{url('menu/create')}}" class="btn btn-sm btn-primary">Tambah Menu</a>
            </div>
          </div>
        </div>
        @if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
@endif
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="menu1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Menu</th>
                <th scope="col">URL</th>
                <th scope="col">Icon</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($menu as $menu)
                  <tr>
                  <td>{{$menu->menu}}</td>
                  <td class="text-wrap">{{$menu->url}}</td>
                  <td><i class="{{$menu->icon}}" data-toggle="tooltip" data-placement="top" title="{{$menu->icon}}"></i></td>
                  <td>
                  <a href="{{url('menu').'/'.$menu->id.'/edit'}}" class="btn btn-warning btn-sm">Edit</a>
                  <form action="{{url('menu').'/'.$menu->id}}" method="post" class="d-inline">
                    @method('delete')
                    @csrf
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                      </form>
                  </td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
@endsection

@section('footer')

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#menu1').DataTable()
        });
        </script>
@endsection