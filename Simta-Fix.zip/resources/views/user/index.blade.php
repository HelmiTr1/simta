@extends('layouts.app')

@section('title')
    Data User
@endsection
@section('content')
<div class="row">
    <div class="col-xl-8">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Data User</h3>
            </div>
            <div class="col text-right">
            <a href="{{url('user/create')}}" class="btn btn-sm btn-primary">Tambah User</a>
            </div>
          </div>
        </div>

        {{session()->get('username')}}
        @if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
@endif
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="user1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Username</th>
                <th scope="col">Password</th>
                <th scope="col">Level</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($user as $user)
                  <tr>
                  <td>{{$user->username}}</td>
                  <td class="text-wrap">{{Str::substr($user->password,7,20)}}</td>
                  <td><span class="badge badge-primary">{{$user->level->level}}</span></td>
                  <td>
                  <a href="{{url('user').'/'.$user->id.'/edit'}}" class="btn btn-warning btn-sm">Edit</a>
                  <form action="{{url('user').'/'.$user->id}}" method="post" class="d-inline">
                    @method('delete')
                    @csrf
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                      </form>
                  </td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
@endsection

@section('footer')

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#user1').DataTable()
        });
        </script>
@endsection