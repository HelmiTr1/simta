@extends('layouts.app')

@section('title')
    Data Content
@endsection
@section('content')
<div class="row">
    <div class="col-xl-12">
      <div class="card">
        <div class="card-header border-0">
          <div class="row align-items-center">
            <div class="col">
              <h3 class="mb-0">Data Content</h3>
            </div>
            <div class="col text-right">
            <a href="{{url('content/create')}}" class="btn btn-sm btn-primary">Tambah Content</a>
            </div>
          </div>
        </div>
        @if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
@endif
        <div class="table-responsive">
            
          <!-- Projects table -->
          <table id="content1" class="table align-items-center table-flush">
            <thead class="thead-light">
              <tr>
                <th scope="col">Judul</th>
                <th scope="col">Isi</th>
                <th scope="col">URL</th>
                <th scope="col">Icon</th>
                <th scope="col">Hak Akses</th>
                <th scope="col">Menu</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($content as $content)
                  <tr>
                  <td>{{$content->judul}}</td>
                  <td>{{$content->isi}}</td>
                  <td class="text-wrap">{{$content->url}}</td>
                  <td><i class="{{$content->icon}}" data-toggle="tooltip" data-placement="top" title="{{$content->icon}}"></i></td>
                  <td class="text-wrap">{{$content->level->level}}</td>
                  <td class="text-wrap">{{$content->menu->menu}}</td>
                  <td>
                  <a href="{{url('content').'/'.$content->id.'/edit'}}" class="btn btn-warning btn-sm">Edit</a>
                  <form action="{{url('content').'/'.$content->id}}" method="post" class="d-inline">
                    @method('delete')
                    @csrf
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                      </form>
                  </td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
@endsection

@section('footer')

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#content1').DataTable()
        });
        </script>
@endsection