@extends('layouts.app')
@section('title','Home')

@section('bread')
{{ Breadcrumbs::render('home') }}
@endsection

@section('content')
@if (Auth::user()->level_id == '1')
    
<div class="row">
    <div class="col-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Total User</h5>
                    <span class="h2 font-weight-bold mb-0 text-success">{{$user}}</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow">
                          <i class="ni ni-circle-08"></i>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Total Schedule</h5>
                    <span class="h2 font-weight-bold mb-0 text-success">{{$jadwal}}</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                          <i class="ni ni-calendar-grid-58"></i>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Mahasiswa</h5>
                    <span class="h2 font-weight-bold mb-0 text-success">{{$mhs}}</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-yellow text-white rounded-circle shadow">
                          <i class="ni ni-single-02"></i>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <h5 class="card-title text-uppercase text-muted mb-0">Total Dosen</h5>
                    <span class="h2 font-weight-bold mb-0 text-success">{{$dosen}}</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                          <i class="ni ni-single-02"></i>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
<div class="row">
    <div class="col-xl-12">
      <div class="card">
        <div class="card-body mb-0">
            <div class="text-center">
            <h1 >Welcome, <span class="text-uppercase text-blue">{{Auth::user()->username}}</span></h1>
                <img src="{{url('assets/img/brand/blue.png')}}" alt="SiMTA">
                <p class="mt-3 mb-0 text-sm">
                    <h1>
                        <span class="text-nowrap font-weight-bold"><span class="display-2 text-red">S</span>istem <span class="display-2 text-green">I</span>nformasi <span class="display-2 text-yellow">M</span>anajemen <span class="display-2 text-blue">T</span>ugas <span class="display-2 text-orange">A</span>khir</span>
                    </h1>
                  </p>
            </div>
        </div>
      </div>
    </div>
</div>
@endsection
