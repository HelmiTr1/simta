<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cetak</title>
<link rel="stylesheet" href="{{url('assets/css/bootstrap/bootstrap.css')}}">
<style>
    *{
        font-family: 'Times New Roman', Times, serif;
    }
</style>
</head>
<body>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row text-center">
                <div class="col-xl-2">

                </div>
                <div class="col-xl-8">
                    <img class="mx-auto d-block" src="{{url('assets/img/logo.png')}}" >
                </div>
                <div class="col-xl-2">

                </div>
            </div>
            <div class="row text-center">
                <div class="col-xl-2">

                </div>
                <div class="col-xl-8">
                    <p class="font-weight-bold">LEMBAR REKAPITULASI NILAI TUGAS AKHIR</p>
                </div>
                <div class="col-xl-2">

                </div>
            </div>
            <div class="row">
                <div class="col-xl-2">

                </div>
                <div class="col-xl-8">
                    <p>Identitas Mahasiswa</p>
                </div>
                <div class="col-xl-2">

                </div>
            </div>
        </div>

    </div>
</body>
</html>