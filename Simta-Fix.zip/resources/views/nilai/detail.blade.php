@extends('layouts.app')

@section('title')
    Nilai Sidang
@endsection
@section('bread')
{{ Breadcrumbs::render('isi',$nim) }}
@endsection

@section('content')
<div class="row">
  <div class="col-xl-7">
    <div class="card">
      <div class="card-header border-0 mb-0">
        <div class="row align-items-center">
          <div class="col">
          <h3 class="mb-0">Nilai</h3>
          </div>
        </div>
      </div>
      <hr class="my-0">
      <div class="card-body mt-0">
        <?php $x=0; ?>
        @foreach ($dosen as $data)
        <?php $dosenM = DB::table('tb_dosen')->where('nidn',$dosen[$x])->get();?>
        <div class="list-group list-group-flush">
          @foreach ($dosenM as $data)
          <a data-toggle="collapse" href="#dosen{{$x}}" role="button" aria-expanded="false" aria-controls="collapseExample" class="text-primary list-group-item list-group-item-action d-flex justify-content-between ">{{$data->nama}}
          <span ><i class="ni ni-bold-down"></i></span></a>
          <div class="collapse" id="dosen{{$x}}">
            <div class="card card-body">
              <?php $bimbinganM = DB::table('tb_bimbingan')->where('nim',$nim)->get()->first();?>
              <ul class="list-group list-group-flush">
                <?php $j=0; $tot=array();?>
                @foreach ($aspekNilai as $data)
                <?php $nilaiM = DB::table('tb_nilaisidang')->where('id_dosen',$dosen[$x])->where('id_aspeknilai',$data->id)->where('id_bimbingan',$bimbinganM->id)->get(); ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  {{$data->aspeknilai}}
                  @if (count($nilaiM)==0)
                  <span >{{__('0')}}</span>
                  @endif
                  @foreach ($nilaiM as $nil)
                  <?php $tot[$j]= $nil->nilai;  ?>
                    <span >{{$nil->nilai}}</span>
                    @endforeach
                    </li>
                    <?php
                    $bot[$j]= $data->bobot/100;
                    $j++; 
                    ?>
                @endforeach
                <li class="list-group-item d-flex justify-content-between align-items-center font-weight-bold">
                  Total
                <span><?php 
                if(count($tot)==0){
                  ?>
                  {{__('0')}}
                  <?php
                }else{
                  $bot2 = 0;
                  for ($i=0; $i < count($aspekNilai); $i++) { 
                    $bot2 += $bot[$i]*$tot[$i];
                  }
                  ?>
                  {{$bot2}}
                  <?php
                }
                ?></span>
                </li>
              </ul>
                </div>
          </div>
          @endforeach
        </div>
        <?php $x++; ?>
        @endforeach
      </div>
      </div>
    </div>
  
    </div>
@endsection